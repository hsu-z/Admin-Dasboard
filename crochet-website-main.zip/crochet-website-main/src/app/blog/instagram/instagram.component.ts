
/*Website Crochet Client - Teresa Costa
  Created: 26, April, 2021*/

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instagram',
  templateUrl: './instagram.component.html',
  styleUrls: ['./instagram.component.scss']
})
export class InstagramComponent implements OnInit {



  constructor() { }

  ngOnInit(): void {
  }

}
