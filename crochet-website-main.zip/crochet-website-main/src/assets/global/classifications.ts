'use strict';

export const crochetCategories = ["Rugs","Baskets","Decor","Sousplat","Flowers","Squares", "Tricotin"];