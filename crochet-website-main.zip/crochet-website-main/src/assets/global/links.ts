'use strict';

export const storeLink = `https://www.etsy.com/ca/shop/ItchToStitchByTeresa?ref=profile_header`;